GLGraphicsItem
==============

.. autoclass:: pyqtgraph.opengl.GLGraphicsItem.GLGraphicsItem
    :members:

    .. automethod:: pyqtgraph.opengl.GLGraphicsItem.GLGraphicsItem.__init__

