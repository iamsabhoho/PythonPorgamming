ParameterTree
=============

.. autoclass:: pyqtgraph.parametertree.ParameterTree
    :members:

    .. automethod:: pyqtgraph.parametertree.ParameterTree.__init__

