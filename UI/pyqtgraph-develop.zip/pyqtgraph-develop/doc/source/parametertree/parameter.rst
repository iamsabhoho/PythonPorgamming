Parameter
=========

.. autoclass:: pyqtgraph.parametertree.Parameter
    :members:

    .. automethod:: pyqtgraph.parametertree.Parameter.__init__

