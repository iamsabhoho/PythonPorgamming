ColorMap
========

.. autoclass:: pyqtgraph.ColorMap
    :members:

    .. automethod:: pyqtgraph.ColorMap.__init__

