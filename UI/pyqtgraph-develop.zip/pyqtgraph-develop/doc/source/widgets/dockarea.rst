dockarea module
===============

.. automodule:: pyqtgraph.dockarea
    :members:
