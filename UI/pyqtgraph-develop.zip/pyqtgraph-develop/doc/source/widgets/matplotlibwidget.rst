MatplotlibWidget
================

.. autoclass:: pyqtgraph.widgets.MatplotlibWidget.MatplotlibWidget
    :members:

    .. automethod:: pyqtgraph.widgets.MatplotlibWidget.MatplotlibWidget.__init__

