parametertree module
====================

.. automodule:: pyqtgraph.parametertree
    :members:
