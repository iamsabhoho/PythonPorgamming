GradientEditorItem
==================

.. autoclass:: pyqtgraph.GradientEditorItem
    :members:

    .. automethod:: pyqtgraph.GradientEditorItem.__init__
    
    
TickSliderItem
==================

.. autoclass:: pyqtgraph.TickSliderItem
    :members:

    .. automethod:: pyqtgraph.TickSliderItem.__init__
    


