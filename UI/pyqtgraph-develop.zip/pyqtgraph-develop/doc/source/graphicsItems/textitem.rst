TextItem
========

.. autoclass:: pyqtgraph.TextItem
    :members:

    .. automethod:: pyqtgraph.TextItem.__init__

